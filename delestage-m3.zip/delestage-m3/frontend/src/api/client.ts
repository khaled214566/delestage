import axios from 'axios';

const apiClient = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to attach JWT token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for auth errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default apiClient;

// Health check API — mirrors backend/app/schemas/health.py::HealthResponse.
// feeder_count and sheddable_mw are the M1 signal: they come straight from
// the seeded grid tables and the v_sheddable_feeders view, so a nonzero
// value here is live proof that M1's schema + seed data are working.
export interface HealthResponse {
  status: string;
  version: string;
  environment: string;
  db_connected: boolean;
  feeder_count: number;
  sheddable_mw: number;
}

export const checkHealth = async (): Promise<HealthResponse> => {
  const { data } = await apiClient.get<HealthResponse>('/health');
  return data;
};

// --- Deficit computation (M3 / UC1) — mirrors backend/app/schemas/deficit.py ---

export type DeficitPlanStatus = 'DRAFT' | 'VALIDATED';
export type OrderMode = 'J-1' | 'REAL_TIME';

export interface DeficitSlot {
  id: number;
  plan_id: number;
  slot_start: string;
  slot_end: string;
  demand_mw: number;
  generation_mw: number;
  imports_mw: number;
  margin_mw: number;
  deficit_mw: number;
  updated_at: string;
}

export interface DeficitPlan {
  id: number;
  date: string;
  mode: OrderMode;
  status: DeficitPlanStatus;
  created_by: number;
  created_at: string;
  validated_by: number | null;
  validated_at: string | null;
  slots: DeficitSlot[];
}

export interface DeficitRevision {
  id: number;
  slot_id: number;
  changed_by: number;
  changed_at: string;
  old_values: Record<string, number>;
  new_values: Record<string, number>;
}

export interface CsvImportResult {
  created: number;
  updated: number;
  slots: DeficitSlot[];
}

export const listPlans = async (): Promise<DeficitPlan[]> => {
  const { data } = await apiClient.get<DeficitPlan[]>('/deficit/plans');
  return data;
};

export const createPlan = async (date: string, mode: OrderMode): Promise<DeficitPlan> => {
  const { data } = await apiClient.post<DeficitPlan>('/deficit/plans', { date, mode });
  return data;
};

export const getPlan = async (planId: number): Promise<DeficitPlan> => {
  const { data } = await apiClient.get<DeficitPlan>(`/deficit/plans/${planId}`);
  return data;
};

export const editSlot = async (
  planId: number,
  slotId: number,
  patch: Partial<Pick<DeficitSlot, 'demand_mw' | 'generation_mw' | 'imports_mw' | 'margin_mw'>>,
): Promise<DeficitSlot> => {
  const { data } = await apiClient.patch<DeficitSlot>(`/deficit/plans/${planId}/slots/${slotId}`, patch);
  return data;
};

export const importCsv = async (planId: number, csvText: string): Promise<CsvImportResult> => {
  const form = new FormData();
  form.append('file', new Blob([csvText], { type: 'text/csv' }), 'import.csv');
  // The instance default is 'application/json' (see apiClient above); for a
  // FormData body that must be unset, not overridden, so the browser can
  // generate 'multipart/form-data; boundary=...' itself — a hardcoded
  // Content-Type here would have the wrong (missing) boundary and the
  // server would fail to parse the body.
  const { data } = await apiClient.post<CsvImportResult>(`/deficit/plans/${planId}/import-csv`, form, {
    headers: { 'Content-Type': undefined },
  });
  return data;
};

export const validatePlan = async (planId: number): Promise<DeficitPlan> => {
  const { data } = await apiClient.post<DeficitPlan>(`/deficit/plans/${planId}/validate`);
  return data;
};

export const getSlotRevisions = async (planId: number, slotId: number): Promise<DeficitRevision[]> => {
  const { data } = await apiClient.get<DeficitRevision[]>(`/deficit/plans/${planId}/slots/${slotId}/revisions`);
  return data;
};